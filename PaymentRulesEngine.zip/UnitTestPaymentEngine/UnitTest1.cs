using PaymentRulesEngine.Payment;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace UnitTestPaymentEngine
{
    

    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void PaymentFactory_Should_Generate_PackagingSlip_ForPhysicalProduct()
        {
            //Arrange
            int physicalProduct = PaymentType.PhysicalProduct.GetHashCode();
            IPayment paymentObject = FactoryPayment.GetPaymentObject(physicalProduct);
            //Act
            bool result = paymentObject.GeneratePayment();
            //Assert
            Assert.AreEqual(result, true);
        }

    }
}
